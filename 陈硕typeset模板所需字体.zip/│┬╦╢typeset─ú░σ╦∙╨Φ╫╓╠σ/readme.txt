﻿Times New Roman   拷贝自 C:/Windows/Fonts
Adobe中文字体     http://ishare.iask.sina.com.cn/f/15105086.html
URW Palladio L    http://www.azfonts.net/families/urw-palladio-l.html
Nimbus Sans L     http://ufonts.com/download/nimbus-sans-l-regular/187518.html 
URW Gothic L      http://www.azfonts.net/families/urw-gothic-l.html
Ubuntu Condensed  http://font.ubuntu.com/ 里面的 Ubuntu-C.ttf
Linux Libertine   http://sourceforge.net/projects/linuxlibertine/
PT Sans Narrow    http://www.paratype.com/public/
Latin Modern Mono http://www.gust.org.pl/projects/e-foundry/latin-modern